%% 1. Sistem cu timp mort
clc; close all; clear all;
T = 2;
taum = 0.5;
num1 = [1]; 
den1 = [T 1];
eps_his = 0
b1 = 1.05;
Aosc1 = 2.1/2;
Tosc1 = 2.37; %2.367
wosc1 = 2*pi/Tosc1;
%run('sistem_1_timp_mort.slx')
kc1 = 4*b1/Aosc1/pi; % functia de descriere kc = A

% 1.1. regulator ziegler nichols => nu merge
    %PI
    Kp_PI_ZN = 0.45*kc1;
    Ti_PI_ZN = 0.8 * Tosc1;

    %PID
    Kp_PID_ZN = 0.6*kc1;
    Ti_PID_ZN = 0.5 * Tosc1;
    Td_PID_ZN = 0.12*Ti_PID_ZN;

% 1.2 regulator impunere margine de castig (mk)
    
    %PID
    mk = 0.75
    db(mk)
    wc1 = wosc1;
    Kp_PID_MARG_Castig = -mk/kc1;
    Td_PID_MARG_Castig = 1/(wc1*sqrt(kc1));
    Ti_PID_MARG_Castig = 2*Td_PID_MARG_Castig;



% 1.3 regulator impunere margine de faza (gamma k)
    %PID
    alpha1=10;
    gamaK1 = pi/4;
    Kp_PID_MARG_faza = kc1*cos(gamaK1);
    Td_PID_MARG_faza = (tan(gamaK1) + sqrt(4/alpha1 + tan(gamaK1)^2))/(2*wc1)
    Ti_PID_MARG_faza = alpha1*Td_PID_MARG_faza;
    kc1*Kp_PID_MARG_faza


%bode(tf(num1,den1,'iodelay', taum)) timpul mort nu afecteaa modulul
%nyquist(tf(num,den,'iodelay', taum))


%% 2. Sistem oscilant
clc; close all; clear all;
tita = 0.35;
w0 = 0.7;
num2 = w0^2;
den2 = conv([1 1],[1 2*tita*w0 w0^2]);
b2 = 1;
Aosc2 = 0.9105/2;
Tosc2 = 13.6;
% b2 = 0.8;
% Aosc2 = 2.422/2;
% Tosc2 = 7.62;
kc2 = 4*b2/Aosc2/pi % functia de descriere kc = A
wosc2 = 2*pi/Tosc2;


%nyquist(tf(num,den))
% 2.1. regulator ziegler nichols 
    %PI
    Kp_PI_ZN = 0.45*kc2;
    Ti_PI_ZN = 0.8 * Tosc2;

    %PID
    Kp_PID_ZN = 0.6*kc2;
    Ti_PID_ZN = 0.5 * Tosc2;
    Td_PID_ZN = Ti_PID_ZN/4;

% 2.2 regulator impunere margine de castig (mk)
    %se impune marg. faza = pi/4 in bucla deschisa
    %PID
   %PID
    mk2 = db(1/2)
    wc2 = wosc2;
    Kp_PID_MARG_Castig = -mk2/kc2;
    Td_PID_MARG_Castig = 1/(wc2*sqrt(kc2));
    Ti_PID_MARG_Castig = 2*Td_PID_MARG_Castig;


% 2.3 regulator impunere margine de faza (gamma k)
    %PID
    alpha2=0.9;
    gamaK2 = pi/4;
    Kp_PID_MARG_faza = kc2*cos(gamaK2);
    Td_PID_MARG_faza = (tan(gamaK2) + sqrt(4/alpha2 + tan(gamaK2)^2))/(2*wc2)
    Ti_PID_MARG_faza = alpha2*Td_PID_MARG_faza;
    kc2*Kp_PID_MARG_faza

%bode(tf(num2,den2))

%% 3. Sistem cu timp mort si integrator
clc; close all; clear all;
T = 2;
taum = 0.5;
num3 = [1];
den3 = [T 1];
b3 = 2;
run('sistem_3_timp_mort_cu_integrator.slx')
Aosc3 = 4.088/2;
Tosc3 = 4.56;
kc3 = 4*b3/Aosc3/pi % functia de descriere kc = A
wosc3 = 2*pi/Tosc3;


% 3.1. regulator ziegler nichols => nu merge
    %PI
    Kp_PI_ZN = 0.45*kc3;
    Ti_PI_ZN = 0.8 * Tosc3;

    %PID
    Kp_PID_ZN = 0.6*kc3;
    Ti_PID_ZN = 0.5 * Tosc3;
    Td_PID_ZN = Ti_PID_ZN/4;

% 3.2 regulator impunere margine de castig (mk)
    %se impune marg. faza = pi/4 in bucla deschisa
    %PID
   %PID
    mk3 = db(1/2)
    wc3 = wosc3;
    Kp_PID_MARG_Castig = -mk3/kc3;
    Td_PID_MARG_Castig = 1/(wc3*sqrt(kc3));
    Ti_PID_MARG_Castig = 2*Td_PID_MARG_Castig;


% 3.3 regulator impunere margine de faza (gamma k)
    %PID
    alpha3=0.9;
    gamaK3 = pi/4;
    Kp_PID_MARG_faza = kc3*cos(gamaK3);
    Td_PID_MARG_faza = (tan(gamaK3) + sqrt(4/alpha3 + tan(gamaK3)^2))/(2*wc3)
    Ti_PID_MARG_faza = alpha3*Td_PID_MARG_faza;
    kc3*Kp_PID_MARG_faza

%bode(tf(num2,den2))

% kt = i/Ti (integrtor) constanta de urmarire
